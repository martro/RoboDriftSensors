#include "DataToWindowRaceUser.h"

DataToWindowRaceUser::DataToWindowRaceUser()
{
    Difference.clear();
    SensorPosition = -1;
    TeamName.clear();
    CarName.clear();
    CurrentTime.clear();
    LightsMode = 11;
    Category.clear();
}
 void DataToWindowRaceUser::clear()
 {
     Difference.clear();
     SensorPosition = -1;
     TeamName.clear();
     CarName.clear();
     CurrentTime.clear();
     LightsMode = 11;
     Category.clear();
 }
